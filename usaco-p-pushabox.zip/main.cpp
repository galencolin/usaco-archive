#include <bits/stdc++.h>
#include <chrono> 
 
using namespace std;
using namespace std::chrono; 
 
// #pragma GCC target ("avx2")
// #pragma GCC optimization ("O3")
// #pragma GCC optimization ("unroll-loops")
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define pb push_back
#define io {ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define mp make_pair
#define f first
#define s second
#define presum(p, a, n) {p[0] = a[0]; for (int i = 1; i < n; i++) p[i] = a[i] + p[i-1];}
#define all(v) v.begin(), v.end()
#define readgraph(list, edges) for (int i = 0; i < edges; i++) {int a, b; cin >> a >> b; a--; b--; list[a].pb(b); list[b].pb(a);}
#define ai(a, n) for (int ele = 0; ele < n; ele++) cin >> a[ele];
#define ain(a, lb, rb) for (int ele = lb; ele <= rb; ele++) cin >> a[ele];
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
#define aout(a, lb, rb) {for (int ele = lb; ele <= rb; ele++) { if (ele > lb) cout << " "; cout << a[ele]; } cout << '\n';}
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
template<typename A, typename B> ostream& operator<<(ostream &cout, pair<A, B> const &p) { return cout << "(" << p.f << ", " << p.s << ")"; }
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v) {
  cout << "["; for(int i = 0; i < v.size(); i++) {if (i) cout << ", "; cout << v[i];} return cout << "]";
}
// template<typename A, typename B> ll max(A x, B y) {
//   return x > y ? x : y;
// }
// template<typename A, typename B> ll min(A x, B y) {
//   return x < y ? x : y;
// }
 
mt19937 rng(steady_clock::now().time_since_epoch().count());
/* usage - just do rng() */
 
void usaco(string filename) {
  #pragma message("be careful, freopen may be wrong")
	freopen((filename + ".in").c_str(), "r", stdin);
	freopen((filename + ".out").c_str(), "w", stdout);
}
 
ll n, m, k, q, Q, T, l, r, x, y, z;
int a[500005];
int b[500005];
string s, t;
ll ans = 0;

bool vis[1505][1505][4];
bool on[1505][1505];
bool at[1505][1505];
bool fgrid[1505][1505];
map<int, int> comp[1505][1505];
pii bes, box;

const int dr[4] = {-1, 0, 1, 0};
const int dc[4] = {0, -1, 0, 1};

bool valid(int r, int c) {
  return r >= 0 && r < n && c >= 0 && c < m;
}

void dfs(int r, int c) {
  at[r][c] = 1;
  f0r(i, 4) if (valid(r + dr[i], c + dc[i]) && !at[r + dr[i]][c + dc[i]] && on[r + dr[i]][c + dc[i]] && box != mp(r + dr[i], c + dc[i])) dfs(r + dr[i], c + dc[i]);
}

int _time = 0;

int disc[2250005];
int lvertex[2250005];
int par[2250005];

int cnum = 0;
vector<pii> elist;

void bcc(int v) {
  disc[v] = lvertex[v] = ++_time;
  int cr = v / m, cc = v % m;
  if (!on[cr][cc]) return;

  int child = 0;

  bool f = 0;

  f0r(i, 4) {
    int nr = cr + dr[i], nc = cc + dc[i];

    if (!valid(nr, nc) || !on[nr][nc]) continue;

    int id = nr * m + nc;

    if (disc[id] == -1) {
      child++;
      par[id] = v;

      elist.pb(mp(v, id));
      bcc(id);

      lvertex[v] = min(lvertex[v], lvertex[id]);

      if ((par[v] == -1 && child > 1) || (par[v] != -1 && lvertex[id] >= disc[v])) {
        ++cnum;
        while (elist.back().f != v || elist.back().s != id) {
          int v1 = elist.back().f, v2 = elist.back().s;
          comp[v1 / m][v1 % m][v2] = cnum;
          comp[v2 / m][v2 % m][v1] = cnum;
          elist.pop_back();
        }
        int v1 = elist.back().f, v2 = elist.back().s;
        comp[v1 / m][v1 % m][v2] = cnum;
        comp[v2 / m][v2 % m][v1] = cnum;
        elist.pop_back();
      }
    } else if (id != par[v]) {
      lvertex[v] = min(lvertex[v], disc[id]); 
      if (disc[id] < disc[v]) { 
        elist.pb(mp(v, id)); 
      } 
    }
  }
}

int main() {
  io;
  // freopen("case", "r", stdin);
  // freopen("test.txt", "r", stdin);
  // freopen("case", "w", stdout);

  usaco("pushabox");
  
  cin >> n >> m >> Q;
  f0r(i, n) {
    cin >> s;
    f0r(j, m) {
      on[i][j] = (s[j] != '#');
      if (s[j] == 'A') bes = {i, j};
      if (s[j] == 'B') box = {i, j};
    }
  }

  // find components
  f0r(i, n*m) {
    disc[i] = -1;
    lvertex[i] = -1;
    par[i] = -1;
  }

  f0r(i, n*m) {
    if (on[i / m][i % m] && disc[i] == -1) bcc(i);

    if (elist.size()) ++cnum;
    while (elist.size()) {
      int v1 = elist.back().f, v2 = elist.back().s;
      comp[v1 / m][v1 % m][v2] = cnum;
      comp[v2 / m][v2 % m][v1] = cnum;
      elist.pop_back();
    }
  }

  ms(at, 0);
  dfs(bes.f, bes.s);

  queue<pair<pii, int> > q;
  f0r(i, 4) {
    int nr = box.f + dr[i], nc = box.s + dc[i];
    if (valid(nr, nc) && at[nr][nc]) {
      q.push(mp(box, i));
    }
  }

  ms(vis, 0);
  while (!q.empty()) {
    pair<pii, int> x = q.front();
    q.pop();

    int cr = x.f.f, cc = x.f.s;
    vis[cr][cc][x.s] = 1;

    int pos = (x.s + 2) % 4;
    pii newbox = mp(cr + dr[pos], cc + dc[pos]);
    if (valid(newbox.f, newbox.s) && on[newbox.f][newbox.s]) {
      if (!vis[newbox.f][newbox.s][x.s]) {
        q.push(mp(newbox, x.s));
        vis[newbox.f][newbox.s][x.s] = 1; 
      }
    } 

    f0r(i, 4) {
      if (i == x.s) continue;
      int nr = cr + dr[i], nc = cc + dc[i];
      if (!valid(nr, nc) || !on[nr][nc]) continue;

      int xr = cr + dr[x.s], xc = cc + dc[x.s];

      int nid = nr * m + nc;
      int xid = xr * m + xc;
      if (comp[cr][cc][nid] && comp[cr][cc][nid] == comp[cr][cc][xid]) {
        if (!vis[cr][cc][i]) {
          q.push(mp(x.f, i));
          vis[cr][cc][i] = 1;
        }
      }
    }
  }

  f0r(i, n) {
    f0r(j, m) {
      bool f = 0;
      f0r(k, 4) f |= vis[i][j][k];
      f &= on[i][j];
      if (box == (pii)mp(i, j)) f = 1;
      fgrid[i][j] = f;
    }
  }

  f0r(i, Q) {
    cin >> x >> y;
    cout << (fgrid[--x][--y] ? "YES\n" : "NO\n");
  }
}
