// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("div7.in");
ofstream fout("div7.out");

int main() {
  int n;
  fin >> n;
  int arr[n+2];
  arr[0] = 0;
  f0r(i, n) fin >> arr[i+1];

  int low[7];
  int hi[7];
  for (int i = 0; i < 7; i++) low[i] = n;
  ms(hi, 0);
  int pre[n+1];
  pre[0] = arr[0] % 7;
  low[pre[0]] = 0;
  cout << pre[0] << endl;
  f1r(i, 1, n+1) {
    pre[i] = (pre[i-1] + arr[i]) % 7;
    // cout << pre[i] << endl;
    low[pre[i]] = min(i, low[pre[i]]);
    hi[pre[i]] = max(i, hi[pre[i]]);
  }

  int ma = 0;
  f0r(i, 7) {
    ma = max(hi[i] - low[i], ma);
    // cout << ma << endl;
  }

  fout << ma << endl;
}