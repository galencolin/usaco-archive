#include <bits/stdc++.h>
#include <chrono> 
 
using namespace std;
using namespace std::chrono; 
 
// #pragma GCC target ("avx2")
// #pragma GCC optimization ("O3")
// #pragma GCC optimization ("unroll-loops")
// #pragma optimization_level 3
// #pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math,O3")
// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define pb push_back
#define io {ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define mp make_pair
#define f first
#define s second
#define presum(p, a, n) {p[0] = a[0]; for (int i = 1; i < n; i++) p[i] = a[i] + p[i-1];}
#define all(v) v.begin(), v.end()
#define getunique(v) {sort(all(v)); v.erase(unique(all(v)), v.end());}
#define readgraph(list, edges) for (int i = 0; i < edges; i++) {int a, b; cin >> a >> b; a--; b--; list[a].pb(b); list[b].pb(a);}
#define ai(a, n) for (int ele = 0; ele < n; ele++) cin >> a[ele];
#define ain(a, lb, rb) for (int ele = lb; ele <= rb; ele++) cin >> a[ele];
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
#define aout(a, lb, rb) {for (int ele = lb; ele <= rb; ele++) { if (ele > lb) cout << " "; cout << a[ele]; } cout << '\n';}
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v);
template<typename A, typename B> ostream& operator<<(ostream &cout, pair<A, B> const &p) { return cout << "(" << p.f << ", " << p.s << ")"; }
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v) {
  cout << "["; for(int i = 0; i < v.size(); i++) {if (i) cout << ", "; cout << v[i];} return cout << "]";
}
template<typename A, typename B> istream& operator>>(istream& cin, pair<A, B> &p) {
  cin >> p.first;
  return cin >> p.second;
}
 
// template<typename A, typename B> ll max(A x, B y) {
//   return x > y ? x : y;
// }
// template<typename A, typename B> ll min(A x, B y) {
//   return x < y ? x : y;
// }
 
mt19937 rng(steady_clock::now().time_since_epoch().count());
/* usage - just do rng() */
 
void usaco(string filename) {
  // #pragma message("be careful, freopen may be wrong")
	freopen((filename + ".in").c_str(), "r", stdin);
	freopen((filename + ".out").c_str(), "w", stdout);
}
 
const lld pi = 3.14159265358979323846;
const int mod = 1000000007;
// const ll mod = 998244353;



int n, m, k, q, Q, T, l, r, x, y, z;
ll a[1000005];
ll b[1000005];
ll c[1000005];
string s, t;
ll ans = 0;

map<pii, vi> qu; /* the query indices for each range */
int res[200005]; /* computed answer for each query */
pii qval[200005]; /* actual query intervals */
int run[25]; /* running count of subsequences ending/starting with i */
int lstor[50005][25], rstor[50005][25]; /* number of subsequences with a lower/upper bound of j, from [mid] to position i */

/* compute lstor from l to r, going left, with fix as an upper bound to elements */
void fill_left(int l, int r, int fix) {
  ms(run, 0);

  f1rd(i, r, l) {
    if (a[i] <= fix) {
      int cnt = 1;
      f1r(j, a[i], fix + 1) cnt = (cnt + run[j]) % mod;
      run[a[i]] = (run[a[i]] + cnt) % mod;
    }
    
    lstor[i][fix] = 0;
    f0r(j, k) lstor[i][fix] = (lstor[i][fix] + run[j]) % mod;
  }
}

/* compute rstor from l to r, going right, with fix as a lower bound to elements */
void fill_right(int l, int r, int fix) {
  ms(run, 0);

  f1r(i, l, r + 1) {
    if (a[i] >= fix) {
      int cnt = 1;
      f1r(j, fix, a[i] + 1) cnt = (cnt + run[j]) % mod;
      run[a[i]] = (run[a[i]] + cnt) % mod;
    }

    rstor[i][fix] = 0;
    f0r(j, k) rstor[i][fix] = (rstor[i][fix] + run[j]) % mod;
  }
}
/* compute a range */
void solve(int l, int r) {
  if (l == r) {
    for (int x: qu[mp(l, r)]) res[x] = 1;
    return;
  }

  int m = (l + r) / 2;

  /* don't compute what's unnecessary - this makes it fit under TL */
  if (!qu[mp(l, r)].size()) {
    solve(l, m);
    solve(m + 1, r);
    return;
  }

  f0r(i, k) fill_left(l, m, i);
  f0r(i, k) fill_right(m + 1, r, i);

  for (int x: qu[mp(l, r)]) {
    int ans = 0;
    pii qv = qval[x];

    /* combine at the middle */
    f0r(i, k) {
      ll v = rstor[qv.s][i];
      if (i != k - 1) v = (v - rstor[qv.s][i + 1] + mod) % mod;
      ans = (ans + v * lstor[qv.f][i]) % mod;
    }

    /* number of subsequences solely on left/right */
    ans = (ans + lstor[qv.f][k - 1]) % mod;
    ans = (ans + rstor[qv.s][0]) % mod;

    res[x] = ans;
  }

  solve(l, m);
  solve(m + 1, r);
}

/* where does each query go */
void part(int i, int ql, int qr, int l, int r) {
  if (l == r) {
    qu[mp(l, r)].pb(i);
    return;
  }
  int m = (l + r) / 2;

  if (ql <= m && m < qr) {
    qu[mp(l, r)].pb(i);
    return;
  }

  if (qr <= m) part(i, ql, qr, l, m);
  else part(i, ql, qr, m + 1, r);
}

int main() {
  io;
  // freopen("case", "r", stdin);
  // freopen("test.txt", "r", stdin);
  // freopen("case", "w", stdout);
  // freopen("file.in", "r", stdin);
 
  usaco("nondec");

  cin >> n >> k;
  ai(a, n);
  f0r(i, n) --a[i];

  cin >> q;
  f0r(i, q) {
    cin >> l >> r;
    part(i, --l, --r, 0, n - 1);
    qval[i] = mp(l, r);
  }

  solve(0, n - 1);

  f0r(i, q) cout << (res[i] + 1) % mod << '\n';
}