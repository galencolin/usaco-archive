#include <bits/stdc++.h>
#include <chrono> 
 
using namespace std;
using namespace std::chrono; 
 
#pragma GCC target ("avx2")
#pragma GCC optimization ("O3")
#pragma GCC optimization ("unroll-loops")
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define pb push_back
#define io {ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define mp make_pair
#define f first
#define s second
#define presum(p, a, n) {p[0] = a[0]; for (int i = 1; i < n; i++) p[i] = a[i] + p[i-1];}
#define all(v) v.begin(), v.end()
#define readgraph(list, edges) for (int i = 0; i < edges; i++) {int a, b; cin >> a >> b; a--; b--; list[a].pb(b); list[b].pb(a);}
#define ai(a, n) for (int ele = 0; ele < n; ele++) cin >> a[ele];
#define ain(a, lb, rb) for (int ele = lb; ele <= rb; ele++) cin >> a[ele];
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
#define aout(a, lb, rb) {for (int ele = lb; ele <= rb; ele++) { if (ele > lb) cout << " "; cout << a[ele]; } cout << '\n';}
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
template<typename A, typename B> ostream& operator<<(ostream &cout, pair<A, B> const &p) { return cout << "(" << p.f << ", " << p.s << ")"; }
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v) {
  cout << "["; for(int i = 0; i < v.size(); i++) {if (i) cout << ", "; cout << v[i];} return cout << "]";
}
// template<typename A, typename B> ll max(A x, B y) {
//   return x > y ? x : y;
// }
// template<typename A, typename B> ll min(A x, B y) {
//   return x < y ? x : y;
// }
 
mt19937 rng(steady_clock::now().time_since_epoch().count());
/* usage - just do rng() */
 
void usaco(string filename) {
  #pragma message("be careful, freopen may be wrong")
	freopen((filename + ".in").c_str(), "r", stdin);
	freopen((filename + ".out").c_str(), "w", stdout);
}
 
const ll mod = 1000000007;
 
ll madd(ll a, ll b) {
  return (a + b) % mod;
}
ll msub(ll a, ll b) {
  return (((a - b) % mod) + mod) % mod;
}
ll mmul(ll a, ll b) {
  return ((a % mod) * (b % mod)) % mod;
}
ll mpow(ll base, ll exp) {
  ll res = 1;
  while (exp) {
    if (exp % 2 == 1){
        res = (res * base) % mod;
    }
    exp >>= 1;
    base = (base * base) % mod;
  }
  return res;
}
ll minv(ll base) {
  return mpow(base, mod - 2);
}
ll mdiv(ll a, ll b) {
  return mmul(a, minv(b));
}
ll gcd(ll x, ll y) {
  if (x == 0) return y;
  if (y == 0) return x;
  return gcd(y, x % y);
}
 
// bool prime[1000006]; 
// void sieve(int n) { 
//   f0r(i, n + 1) prime[i] = 1;
//   for (int p = 2; p * p <= n; p++) { 
//     if (prime[p] == true) { 
//       for (int i = p * p; i <= n; i += p) 
//         prime[i] = false; 
//     } 
//   } 
//   prime[1] = prime[0] = 0;
// } 

ll n, m, k, q, Q, T, l, r, x, y, z;
ll a[100005];
ll b[100005];
string s, t;
ll ans = 0;

ll cnt[1505][2505];
vi has[1505];
ll num[1505];
ll ways[1505];
ll gways = 0;
vpi edges[1505];
ll mark[1505];
bool vis[1505];
ll groups = 0;

void dfs_mark(int v, int par) {
  mark[v] = groups;

  for (pii x: edges[v]) if (x.f != par) dfs_mark(x.f, v);
}

void dfs_cnt(int v, ll dist) {
  if (dist >= y) {
    num[mark[v]] = madd(num[mark[v]], dist);
    ways[mark[v]]++;
  } else {
    cnt[mark[v]][dist]++;
    has[mark[v]].pb(dist);
  }
  vis[v] = 1;

  for (pii x: edges[v]) if (!vis[x.f]) dfs_cnt(x.f, dist + x.s);
}

int main() {
  io;
  // freopen("case", "r", stdin);
  // freopen("test.txt", "r", stdin);
  // freopen("case", "w", stdout);

  usaco("mooriokart");

  cin >> n >> m >> x >> y;
  ms(cnt, 0);
  f0r(i, m) {
    ll a, b, d; cin >> a >> b >> d;
    --a; --b;
    edges[a].pb(mp(b, d));
    edges[b].pb(mp(a, d));
  }
  f0r(i, n) mark[i] = -1;
  f0r(i, n) {
    if (mark[i] != -1) continue;
    dfs_mark(i, -1);
    groups++;
  }
  y = max(0LL, y - groups * x);
  ll bonus = groups * x;
  f0r(i, n) {
    ms(vis, 0);
    dfs_cnt(i, 0);
    cnt[mark[i]][0]--;
    if (y == 0) ways[mark[i]]--;
  }
  f0r(i, groups) f0r(j, y) cnt[i][j] /= 2;
  f0r(i, groups) num[i] = mmul(num[i], minv(2));
  f0r(i, groups) ways[i] = mmul(ways[i], minv(2));
  f0r(i, groups) {
    sort(all(has[i]));
    has[i].erase(unique(all(has[i])), has[i].end());
  }

  ans = num[0];
  gways = ways[0];

  ll ncnt[y + 3];
  for (int i = 1; i < groups; i++) {
    ll last = i - 1, loc = i;
    ll nways = 0, nans = 0;
    if (y > 0) {
      /* k to k */
      
      ms(ncnt, 0);
      ll pre[y + 3][2];
      f0r(j, y) {
        if (j) {
          pre[j + 1][0] = cnt[last][j] + pre[j][0];
          pre[j + 1][1] = j * cnt[last][j] + pre[j][1];
        } else {
          pre[j + 1][0] = cnt[last][j];
          pre[j + 1][1] = 0;
        }
      }
      /* fix the new one */
      for (int j = y - 1; j >= 0; j--) {
        int other = y - j;
        nways = madd(nways, mmul(cnt[loc][j], pre[y][0] - pre[other][0]));
        nans = madd(nans, mmul(cnt[loc][j], madd(mmul(j, pre[y][0] - pre[other][0]), pre[y][1] - pre[other][1])));
      }

      for (int j = y - 1; j >= 0; j--) {
        for (int x: has[loc]) {
          if (j + x >= y) break;
          ncnt[j + x] = madd(ncnt[j + x], mmul(cnt[last][j], cnt[loc][x]));
        }
      }

      /* big to k */
      for (int k = y - 1; k >= 0; k--) {
        nans = madd(nans, mmul(cnt[loc][k], mmul(gways, k)));
        nans = madd(nans, mmul(cnt[loc][k], ans));
        nways = madd(nways, mmul(cnt[loc][k], gways));
      }

      /* k to big */
      for (int k = y - 1; k >= 0; k--) {
        nans = madd(nans, mmul(cnt[last][k], mmul(ways[loc], k)));
        nans = madd(nans, mmul(cnt[last][k], num[loc]));
        nways = madd(nways, mmul(cnt[last][k], ways[loc]));
      }

      for (int k = y - 1; k >= 0; k--) {
        cnt[loc][k] = mmul(2, ncnt[k]);
      }
    }
    
    /* big to big */
    nans = madd(nans, madd(mmul(ways[loc], ans), mmul(gways, num[loc])));
    nways = madd(nways, mmul(ways[loc], gways));

    ans = mmul(nans, 2);
    gways = mmul(nways, 2);
  }

  ans = madd(ans, mmul(gways, bonus));
  f1r(i, 1, groups) ans = mmul(ans, i);

  cout << ans << endl;
}