// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <set>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("sleepy.in");
ofstream fout("sleepy.out");

const int mn = 100010;
int bit[mn];

void add(int x, int v) {
  for(;x < mn; x += (x & -x)) {
    bit[x] += v;
  }
}

int query(int x) {
  int sum = 0;
  for(;x > 0; x -= (x & -x)) {
    sum += bit[x];
  }
  return sum;
}

int main() {
  int n;
  fin >> n;

  int arr[n];
  f0r(i, n) fin >> arr[i];

  int v = n+1;
  for (i = n - 1; i >= 0; i--) {
    if (arr[i] >= v) break;
    v = arr[i];
    add(arr[i], 1);
  }
  k = i + 1;
  fout << k << endl;
  if (!k) exit(0);

  f0r(i, k) {
    if (i) fout << " ";
    fout << (k - i - 1) + query(arr[i]);
    add(arr[i], 1);
  }
  fout << endl;
}