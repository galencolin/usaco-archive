// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <set>
#include <queue>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("cardgame.in");
ofstream fout("cardgame.out");
const int mn = 500001;
bool on[2*mn];
queue<int> el;
set<int> b1;
set<int> b2;

int n;
int main() {
  fin >> n;
  ms(on, 0);
  f0r(i, n) {
    int x; fin >> x;
    on[x-1] = 1;
    if(i < n/2) el.push(x-1);
    else el.push(-(x-1));
  }

  int cnt = 0;
  f0r(i, 2*n) {
    if(!on[i]) {
      if (cnt < n/2) b1.insert(-i);
      else b2.insert(i);
      cnt++;
    }
  }

  int wins = 0;
  f0r(i, n/2) {
    int x = el.front();
    el.pop();
    if (b2.upper_bound(x) != b2.end()) {
      b2.erase(b2.upper_bound(x));
      wins++;
    } else {
      b2.erase(b2.begin());
    }
  }

  f0r(i, n/2) {
    int x = el.front();
    el.pop();
    if (b1.upper_bound(x) != b1.end()) {
      b1.erase(b1.upper_bound(x));
      wins++;
    } else {
      b1.erase(b1.begin());
    }
  }

  fout << wins << endl;
}