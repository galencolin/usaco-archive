// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <set>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("highcard.in");
ofstream fout("highcard.out");

bool arr[100010];
set<int> el, be;
int main() {
  int n;
  fin >> n;

  ms(arr, 0);
  int t;
  f0r(i, n) {
    fin >> t;
    arr[--t] = 1;
  }

  f0r(i, n*2) {
    if (arr[i]) el.insert(i);
    else be.insert(i);
  }

  int win = 0;
  for (int i: el) {
    auto v = be.upper_bound(i);
    if (v != be.end()) {
      ++win;
      be.erase(v);
    } else {
      be.erase(be.begin());
    }
  }

  fout << win << endl;
}