/* this code doesn't have the massive template because i attempted this much earlier */

#include "grader.h"
#include <bits/stdc++.h>

using namespace std;

int call = 0;
pair<int, int> locs[100001];
int size[100001];
bool v[100001];
vector<int> edges[100001];

const int lg = 18;
int lift[100005][lg];
int depth[100005];

void dfs(int v, int par) {
  size[v] = 1;
  lift[v][0] = par;

  for (int i = 1; i < lg; i++) {
    if (lift[v][i - 1] == -1) break;
    lift[v][i] = lift[lift[v][i - 1]][i - 1];
  }

  for (int x: edges[v]) {
    if (x != par) {
      depth[x] = depth[v] + 1;
      dfs(x, v);
      size[v] += size[x];
    }
  }
}

/* assume locs[i] exists */
void dfs2(int i) {
  v[i] = 1;
  setFarmLocation(i, locs[i].first, locs[i].second);
  int acc = 0;
  for (int j: edges[i]) {
    if (!v[j]) {
      locs[j] = make_pair(
        locs[i].first + size[i] - size[j] - acc,
        1 + locs[i].second + acc);
      dfs2(j);
      acc += size[j];
    }
  }
}

void addRoad(int a, int b) {
  call++;
  edges[a].push_back(b);
  edges[b].push_back(a);
}

void buildFarms() {
  depth[0] = 0;
  dfs(0, -1);
  memset(v, 0, sizeof(v));
  locs[0] = make_pair(1, 1);
  dfs2(0);
}

int get(int v, int k) {
  for (int i = lg - 1; i >= 0; i--) {
    if ((1 << i) <= k) {
      v = lift[v][i];
      k -= (1 << i);
    }
  }
  return v;
}

void notifyFJ(int a, int b) {
  if (depth[a] < depth[b]) swap(a, b);
  int d = depth[a] - depth[b];
  int v = get(a, d);
  if (v == b) {
    addBox(locs[v].first, locs[v].second, locs[a].first, locs[a].second);
  } else {
    int preva = a, prevb = b;
    a = v;
    for (int i = lg - 1; i >= 0; i--) {
      if (lift[a][i] != lift[b][i]) {
        a = lift[a][i];
        b = lift[b][i];
      }
    }
    b = lift[b][0];
    addBox(locs[b].first, locs[b].second, locs[prevb].first, locs[prevb].second);
    addBox(locs[a].first, locs[a].second, locs[preva].first, locs[preva].second);
    // cout << preva << " " << prevb << " " << a << " " << b << endl;
  }
}
