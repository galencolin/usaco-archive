#include <bits/stdc++.h>
#include <chrono> 
 
using namespace std;
using namespace std::chrono; 
 
// #pragma GCC target ("avx2")
// #pragma GCC optimization ("O3")
// #pragma GCC optimization ("unroll-loops")
// #pragma optimization_level 3
// #pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math,O3")
// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
 
#define f0r(a, b) for (int a = 0; a < b; a++)
#define f1r(a, b, c) for (int a = b; a < c; a++)
#define f0rd(a, b) for (int a = b; a >= 0; a--)
#define f1rd(a, b, c) for (int a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define pb push_back
#define io {ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define mp make_pair
#define f first
#define s second
#define presum(p, a, n) {p[0] = a[0]; for (int i = 1; i < n; i++) p[i] = a[i] + p[i-1];}
#define all(v) v.begin(), v.end()
#define getunique(v) {sort(all(v)); v.erase(unique(all(v)), v.end());}
#define readgraph(list, edges) for (int i = 0; i < edges; i++) {int a, b; cin >> a >> b; a--; b--; list[a].pb(b); list[b].pb(a);}
#define ai(a, n) for (int ele = 0; ele < n; ele++) cin >> a[ele];
#define ain(a, lb, rb) for (int ele = lb; ele <= rb; ele++) cin >> a[ele];
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
#define aout(a, lb, rb) {for (int ele = lb; ele <= rb; ele++) { if (ele > lb) cout << " "; cout << a[ele]; } cout << '\n';}
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v);
template<typename A, typename B> ostream& operator<<(ostream &cout, pair<A, B> const &p) { return cout << "(" << p.f << ", " << p.s << ")"; }
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v) {
  cout << "["; for(int i = 0; i < v.size(); i++) {if (i) cout << ", "; cout << v[i];} return cout << "]";
}
 
// template<typename A, typename B> ll max(A x, B y) {
//   return x > y ? x : y;
// }
// template<typename A, typename B> ll min(A x, B y) {
//   return x < y ? x : y;
// }
 
mt19937 rng(steady_clock::now().time_since_epoch().count());
/* usage - just do rng() */
 
void usaco(string filename) {
  #pragma message("be careful, freopen may be wrong")
	freopen((filename + ".in").c_str(), "r", stdin);
	freopen((filename + ".out").c_str(), "w", stdout);
}
 
const ll mod = 1000000007;



ll n, m, k, q, Q, T, l, r, x, y, z;
ll a[1000005];
ll b[1000005];
ll c[1000005];
string s, t;
ll ans = 0;

ll hcost[30000][5];
ll vcost[6][29999];

int sid[70000];
vector<vi> states;
int premx[135];
int cnt[135][6];
int packed[135];
vi vals;
bool vis[6];
vi blocks;

void flatten(vi& x) {
  int cnt = 0, pt = 0;
  vi mp(k, -1);

  f0r(i, x.size()) {
    if (mp[x[i]] == -1) mp[x[i]] = cnt++;
  }
  f0r(i, x.size()) x[i] = mp[x[i]];
}

int pack(vi& x) {
  int v = 1, r = 0;
  f0rd(i, k - 1) {
    r += x[i] * v;
    v *= k;
  }
  return r;
}

int compmx(vi& v) {
  bool vis[k + 1];
  ms(vis, 0);
  for (int x: v) vis[x] = 1;
  f0r(i, k + 1) if (!vis[i]) return i;
  assert(0);
}

void eval() {
  ms(vis, 0);
  f0r(i, k) vis[vals[i]] = 1;

  int stop;
  f0rd(i, k - 1) {
    if (vis[i]) {
      stop = i;
      break;
    }
  }

  f0r(i, stop) if (!vis[i]) return;

  blocks.clear();
  blocks.pb(vals[0]);
  int pt = 0;
  f1r(i, 1, k) {
    if (vals[i] != vals[i - 1]) {
      blocks.pb(vals[i]);
    }
  }

  f0r(i, blocks.size()) {
    f1r(j, i + 1, blocks.size()) {
      if (blocks[i] == blocks[j]) {
        f1r(l, i + 1, j) {
          f1r(m, j + 1, blocks.size()) {
            if (blocks[l] == blocks[m]) return;
          }
        }
      }
    }
  }

  flatten(vals);

  int p = pack(vals);

  if (sid[p] != -1) return;

  sid[p] = states.size();
  states.pb(vals);

  premx[sid[p]] = compmx(vals);
  ms(cnt[sid[p]], 0);
  f0r(i, k) ++cnt[sid[p]][vals[i]];
}

void recur(int depth) {
  if (depth == k) eval();
  else {
    f0r(i, k) {
      vals[depth] = i;
      recur(depth + 1);
    }
  }
}

void genstates() {
  f0r(i, k) vals.pb(-1);
  f0r(i, 70000) sid[i] = -1;

  recur(0);
}

pair<ll, int> dp[2][6][135];
int trans[135][6][6];
int otrans[135][6][6];
vi state;

void gentrans() {
  f0r(i, states.size()) {
    f0r(j, k) {
      f0r(l, k) {
        state = states[i];
        state[j] = l;
        flatten(state);
        trans[i][j][l] = sid[pack(state)];
      }
    }
  }
}

void genotrans() {
  f0r(i, states.size()) {
    f0r(j, k) {
      f0r(l, k) {
        state = states[i];
        f0r(m, k) if (state[m] == j) state[m] = l;
        flatten(state);
        otrans[i][j][l] = sid[pack(state)];
      }
    }
  }
}

void preset(int r, int c, int l, ll sz, int val) {
  if (l == -1 || val == -1) return;
  pair<ll, int> v = dp[r][c][l];
  if (sz < v.f) v = mp(sz, val);
  else if (sz == v.f) {
    v.s += val;
    if (v.s >= mod) v.s -= mod;
  }
  dp[r][c][l] = v;
}

int main() {
  io;
  // freopen("case", "r", stdin);
  // freopen("test.txt", "r", stdin);
  // freopen("case", "w", stdout);
  // freopen("file.in", "r", stdin);
 
  usaco("escape");

  cin >> n >> k;
  genstates();
  gentrans();
  genotrans();
  int st = states.size();
  // cout << states << endl;
  f0r(i, n) ai(hcost[i], k - 1);
  f0r(i, k) ai(vcost[i], n - 1);

  f0r(i, k) state.pb(0);

  f0r(i, n) {
    int cur = i % 2;
    int last = (i + 1) % 2;
    f0r(j, k) {
      f0r(l, st) dp[cur][j][l] = mp(mod * mod, -1);
      if (i == 0 && j == 0) {
        state[0] = 1;
        flatten(state);
        
        int p = sid[pack(state)];
        preset(cur, j, p, 0, 1);
      } else if (j == 0) {
        f0r(l, st) {
          preset(cur, j, l, dp[last][k - 1][l].f + vcost[j][i - 1], dp[last][k - 1][l].s);

          /* don't take vert */
          int x = premx[l];
          if (x >= k) continue;

          /* only one occurrence, bad move */
          int cn = cnt[l][states[l][j]];
          if (cn <= 1) continue;
          
          int p = trans[l][j][x];
          preset(cur, j, p, dp[last][k - 1][l].f, dp[last][k - 1][l].s);
        }
      } else if (i == 0) {
        f0r(l, st) {
          /* take none */
          int x = premx[l];

          if (x < k) {
            int p = trans[l][j][x];
            preset(cur, j, p, dp[cur][j - 1][l].f, dp[cur][j - 1][l].s);
          }

          /* take only hor */
          int p = trans[l][j][states[l][j - 1]];
          preset(cur, j, p, dp[cur][j - 1][l].f + hcost[i][j - 1], dp[cur][j - 1][l].s);
        }
      } else {
        f0r(l, st) {
          /* take only vert */
          preset(cur, j, l, dp[cur][j - 1][l].f + vcost[j][i - 1], dp[cur][j - 1][l].s);

          /* take none */
          int x = premx[l];

          /* only one occurrence, bad move */
          int cn = cnt[l][states[l][j]];
          if (x < k && cn > 1) {
            int p = trans[l][j][x];
            preset(cur, j, p, dp[cur][j - 1][l].f, dp[cur][j - 1][l].s);
          }

          /* take only hor */
          int p = trans[l][j][states[l][j - 1]];
          if (cn > 1) preset(cur, j, p, dp[cur][j - 1][l].f + hcost[i][j - 1], dp[cur][j - 1][l].s);

          /* take both */
          p = otrans[l][states[l][j]][states[l][j - 1]];
          preset(cur, j, p, dp[cur][j - 1][l].f + hcost[i][j - 1] + vcost[j][i - 1], dp[cur][j - 1][l].s);
        }
      }
    }
  }

  cout << dp[(n + 1) % 2][k - 1][0].s << endl;
} 