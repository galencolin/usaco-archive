#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
// #include <set>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("poetry.in");
ofstream fout("poetry.out");
const ll mod = 1000000007;
const int maxn = 5001, maxm = 100001, maxk = 5001;

ll dp[maxk];
ll vals[maxn];

vector<int> lengths[maxn];
vector<int> wl;

map<char, int> nums;
set<ll> unums;
ll resv[maxm+10];

ll mpow(ll base, ll exp) {
    ll res = 1;
    while (exp) {
        if (exp % 2 == 1){
           res = (res * base) % mod;
        }
        exp = exp >> 1;
        base = (base * base) % mod;
    }
    return res;
}

int main() {
  int n, m;
  fin >> n >> m >> k;

  f0r(i, n) {
    int a, b;
    fin >> a >> b;
    b--;
    wl.pb(a);
    lengths[b].pb(a);
  }

  f0r(i, m) {
    char c;
    fin >> c;
    if (nums.find(c) == nums.end()) {
      nums[c] = 1;
    } else {
      nums[c]++;
    }
  }

  for (auto a: nums) {
    unums.insert((ll)a.second);
  }

  dp[0] = 1;
  f1r(i, 1, k) {
    dp[i] = 0;
    f0r(j, n) {
      if (i - wl[j] >= 0) {
        dp[i] = (dp[i] + dp[i - wl[j]] + mod) % mod;
      }
    }
  }

  f0r(i, n) {
    vals[i] = 0;
    f0r(j, lengths[i].size()) {
      vals[i] = (vals[i] + dp[k - lengths[i][j]] + mod) % mod;
    }
  }

  for (ll ex: unums) {
    ll res = 0;
    f0r(i, n) {
      res = (res + mpow(vals[i], ex) + mod) % mod;
    }
    resv[ex] = res;
  }

  ll ans = 1;
  for (auto a: nums) {
    ans = (ans * resv[a.second] + mod) % mod;
    if (resv[a.second] == 0) exit(0);
  }

  fout << ans << endl;
}