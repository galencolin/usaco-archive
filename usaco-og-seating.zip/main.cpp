#include <bits/stdc++.h>
#include <chrono> 
 
using namespace std;
using namespace std::chrono; 
 
// #pragma GCC target ("avx2")
// #pragma GCC optimization ("O3")
// #pragma GCC optimization ("unroll-loops")
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define pb push_back
#define io {ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define mp make_pair
#define f first
#define s second
#define presum(p, a, n) {p[0] = a[0]; for (int i = 1; i < n; i++) p[i] = a[i] + p[i-1];}
#define all(v) v.begin(), v.end()
#define readgraph(list, edges) for (int i = 0; i < edges; i++) {int a, b; cin >> a >> b; a--; b--; list[a].pb(b); list[b].pb(a);}
#define ai(a, n) for (int ele = 0; ele < n; ele++) cin >> a[ele];
#define ain(a, lb, rb) for (int ele = lb; ele <= rb; ele++) cin >> a[ele];
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
#define aout(a, lb, rb) {for (int ele = lb; ele <= rb; ele++) { if (ele > lb) cout << " "; cout << a[ele]; } cout << '\n';}
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
template<typename A, typename B> ostream& operator<<(ostream &cout, pair<A, B> const &p) { return cout << "(" << p.f << ", " << p.s << ")"; }
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v) {
  cout << "["; for(int i = 0; i < v.size(); i++) {if (i) cout << ", "; cout << v[i];} return cout << "]";
}
// template<typename A, typename B> ll max(A x, B y) {
//   return x > y ? x : y;
// }
// template<typename A, typename B> ll min(A x, B y) {
//   return x < y ? x : y;
// }
 
mt19937 rng(steady_clock::now().time_since_epoch().count());
/* usage - just do rng() */
 
void usaco(string filename) {
  #pragma message("be careful, freopen may be wrong")
	freopen((filename + ".in").c_str(), "r", stdin);
	freopen((filename + ".out").c_str(), "w", stdout);
}
 
const ll mod = 1000000007;
 
ll madd(ll a, ll b) {
  return (a + b) % mod;
}
ll msub(ll a, ll b) {
  return (((a - b) % mod) + mod) % mod;
}
ll mmul(ll a, ll b) {
  return ((a % mod) * (b % mod)) % mod;
}
ll mpow(ll base, ll exp) {
  ll res = 1;
  while (exp) {
    if (exp % 2 == 1){
        res = (res * base) % mod;
    }
    exp >>= 1;
    base = (base * base) % mod;
  }
  return res;
}
ll minv(ll base) {
  return mpow(base, mod - 2);
}
ll mdiv(ll a, ll b) {
  return mmul(a, minv(b));
}
ll gcd(ll x, ll y) {
  if (x == 0) return y;
  if (y == 0) return x;
  return gcd(y, x % y);
}
 
bool prime[1000006]; 
void sieve(int n) { 
  f0r(i, n + 1) prime[i] = 1;
  for (int p = 2; p * p <= n; p++) { 
    if (prime[p] == true) { 
      for (int i = p * p; i <= n; i += p) 
        prime[i] = false; 
    } 
  } 
  prime[1] = prime[0] = 0;
} 

struct segtree {
  int n, depth;
  vector<int> tree, lazy;

  void init(int s, int* arr) {
    n = s;
    tree = vector<int>(4 * s, 0);
    lazy = vector<int>(4 * s, -1);
    init(0, 0, n - 1, arr);
  }

  int init(int i, int l, int r, int* arr) {
    if (l == r) return tree[i] = arr[l];

    int mid = (l + r) / 2;
    int a = init(2 * i + 1, l, mid, arr),
        b = init(2 * i + 2, mid + 1, r, arr);
    return tree[i] = (a > b ? a : b);
  }

  void update(int l, int r, int v) {
	if (l > r) return;
    update(0, 0, n - 1, l, r, v);
  }

  int update(int i, int tl, int tr, int ql, int qr, int v) {
    if (ql <= tl && tr <= qr) {
      lazy[i] = v;
      eval_lazy(i, tl, tr);
      return tree[i];
    }

    eval_lazy(i, tl, tr);

    if (tl > tr || tr < ql || qr < tl) return tree[i];
    if (tl == tr) return tree[i];

    int mid = (tl + tr) / 2;
    int a = update(2 * i + 1, tl, mid, ql, qr, v),
        b = update(2 * i + 2, mid + 1, tr, ql, qr, v);
    return tree[i] = (a > b ? a : b);
  }

  int query(int l, int r) {
	  if (l > r) return 0;
    return query(0, 0, n-1, l, r);
  }

  int query(int i, int tl, int tr, int ql, int qr) {
    eval_lazy(i, tl, tr);
    
    if (ql <= tl && tr <= qr) return tree[i];
    if (tl > tr || tr < ql || qr < tl) return 0;

    int mid = (tl + tr) / 2;
    int a = query(2 * i + 1, tl, mid, ql, qr),
        b = query(2 * i + 2, mid + 1, tr, ql, qr);
    return (a > b ? a : b);
  }

  int search(int val, int i, int tl, int tr) {
    eval_lazy(i, tl, tr);
    if (tl == tr) {
      if (tree[i] >= val) return tl;
      else return tl + 1;
    }

    int mid = (tl + tr) / 2;
    eval_lazy(i * 2 + 1, tl, mid);
    eval_lazy(i * 2 + 2, mid + 1, tr);
    if (tree[i * 2 + 1] >= val) return search(val, i * 2 + 1, tl, mid);
    else return search(val, i * 2 + 2, mid + 1, tr);
  }

  void eval_lazy(int i, int l, int r) {
    if (lazy[i] == -1) return;
    tree[i] = lazy[i];
    if (l != r) {
      lazy[i * 2 + 1] = lazy[i];
      lazy[i * 2 + 2] = lazy[i];
    }

    lazy[i] = -1;
  }
};

ll n, m, k, q, Q, T, l, r, x, y, z;
int a[500005];
int b[500005];
string s, t;
ll ans = 0;

segtree range, tree_left, tree_right;

void fix_0(int l, int r) {
  int lv = l, rv = r;
  if (l != 0) {
    if (range.query(l - 1, l - 1) != 0) lv = tree_left.query(l - 1, l - 1);
  }
  if (r != 0) {
    if (range.query(r + 1, r + 1) != 0) rv = tree_right.query(r + 1, r + 1);
  }
  range.update(lv, rv, rv - lv + 1);
  tree_left.update(lv, rv, lv);
  tree_right.update(lv, rv, rv);
}

void fix_1(int l, int r) {
  range.update(l, r, 0);
  int lv = l, rv = r;
  if (l != 0) {
    if (range.query(l - 1, l - 1) != 0) {
      lv = tree_left.query(l - 1, l - 1);
      range.update(lv, l - 1, l - lv);
      tree_right.update(lv, l - 1, l - 1);
    }
  }
  if (r != 0) {
    if (range.query(r + 1, r + 1) != 0) {
      rv = tree_right.query(r + 1, r + 1);
      range.update(r + 1, rv, rv - r);
      tree_left.update(r + 1, rv, r + 1);
    }
  }
}

int main() {
  io;
  // freopen("case", "r", stdin);
  // freopen("test.txt", "r", stdin);
  // freopen("case", "w", stdout);

  usaco("seating");

  cin >> n >> q;
  ms(a, 0);
  f0r(i, n) b[i] = n;
  range.init(n, b);
  tree_left.init(n, a);
  f0r(i, n) b[i] = n - 1;
  tree_right.init(n, b);
  f0r(i, q) {
    char c; cin >> c;
    if (c == 'A') {
      cin >> x;
      ll ind = range.search(x, 0, 0, n - 1);
      if (ind == n) ans++;
      else fix_1(ind, ind + x - 1);
    } else if (c == 'L') {
      cin >> l >> r;
      --l;
      --r;
      fix_0(l, r);
    }

  }
  cout << ans << endl;
}
