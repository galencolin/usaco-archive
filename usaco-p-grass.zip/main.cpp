/* rip 6/10 */

// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <map>
#include <vector>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("grass.in");
ofstream fout("grass.out");
typedef struct edge edge;
const int mn = 200200;

int col[mn];
vector<edge> edges[mn];
map<int, int> esort;
struct edge {
  int to, from, dist;
  edge() {}
  edge(int a, int b, int c) {
    from = a;
    to = b;
    dist = c;
  }
};

int cnt[1000050], mv = 1e9;

void drop() {
  while (cnt[mv] == 0) ++mv;
}

int n, m, a, b, c;
int main() {
  fin >> n >> m >> k >> q;
  ms(cnt, 0);

  f0r(i, m) {
    fin >> a >> b >> c;
    a--; b--;
    edges[a].pb(edge(a, b, c));
    edges[b].pb(edge(b, a, c));
  }

  f0r(i, n) {
    fin >> col[i];
  }

  f0r(i, n)
    for (edge e: edges[i]) {
      if (e.from < e.to && col[e.from] != col[e.to]) {
        cnt[e.dist]++;
        mv = min(mv, e.dist);
      }
    }

  f0r(j, q) {
    fin >> a >> b;
    --a;
    
    if (b == col[a]) {
      fout << mv << '\n';
      continue;
    }

    int omv = mv;

    f0r(i, edges[a].size()) {
      edge x = edges[a][i];
      if (col[x.to] == b) {
        cnt[x.dist]--;
      } else if (col[x.to] == col[a]) {
        if (x.dist < mv) {
          mv = x.dist;
        } 
        cnt[x.dist]++;
      }
    }

    drop();

    col[a] = b;

    fout << mv << '\n';
  }
}