#include <bits/stdc++.h>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("cardgame.in");
ofstream fout("cardgame.out");
const int mn = 100010;
bool on[mn];
vector<int> order;
vector<int> el;
set<int> b1, b2;
int ans = 0;

int n, first[mn], second[mn];
int main() {
  fin >> n;
  ms(on, 0);
  f0r(i, n) {
    int x; fin >> x;
    on[x - 1] = 1;
    el.push_back(x - 1);
  }

  f0r(i, 2*n) {
    if (!on[i]) {
      b1.insert(i);
      b2.insert(-i);
    }
  }

  first[0] = 0;
  f0r(i, n) {
    if (b1.lower_bound(el[i]) != b1.end()) {
      b1.erase(b1.lower_bound(el[i]));
      first[i + 1] = first[i] + 1;
    } else {
      first[i + 1] = first[i];
    }
  }

  f0r(i, n) el[i] *= -1;
  reverse(el.begin(), el.end());

  second[n] = 0;
  f0r(i, n) {
    if (b2.lower_bound(el[i]) != b2.end()) {
      b2.erase(b2.lower_bound(el[i]));
      second[n - i - 1] = second[n - i] + 1;
    } else {
      second[n - i - 1] = second[n - i];
    }
  }
  
  int ans = 0;
  f0r(i, n + 1) ans = max(ans, first[i] + second[i]);
  fout << ans << endl;
}