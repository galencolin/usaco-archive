#include <bits/stdc++.h>

using namespace std;

int n, k;
int v[50005], pre[50005];
bool vi[50005];
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

struct lca_lift {
  const int lg = 18;
  int n;
  vector<int> depth;
  vector<vector<int> > edges;
  vector<vector<int> > lift;
  
  void init(int sz) {
    n = sz;
    depth = vector<int>(n);
    edges = vector<vector<int> >(n, vector<int>());
    lift = vector<vector<int> >(n, vector<int>(lg, -1));
  }

  void edge(int a, int b) {
    edges[a].push_back(b);
    edges[b].push_back(a);
  }

  void attach(int node_to_attach, int node_to_attach_to) {
    int a = node_to_attach, b = node_to_attach_to;
    edge(a, b);

    lift[a][0] = b;

    for (int i = 1; i < lg; i++) {
      if (lift[a][i - 1] == -1) break;
      lift[a][i] = lift[lift[a][i - 1]][i - 1];
    }

    depth[a] = depth[b] + 1;
  }

  void init_lift() {
    depth[0] = 0;
    dfs(0, -1);
  }

  void dfs(int v, int par) {
    lift[v][0] = par;

    for (int i = 1; i < lg; i++) {
      if (lift[v][i - 1] == -1) break;
      lift[v][i] = lift[lift[v][i - 1]][i - 1];
    }

    for (int x: edges[v]) {
      if (x != par) {
        depth[x] = depth[v] + 1;
        dfs(x, v);
      }
    }
  }

  int get(int v, int k) {
    for (int i = lg - 1; i >= 0; i--) {
      if ((1 << i) <= k) {
        v = lift[v][i];
        k -= (1 << i);
      }
    }
    return v;
  }

  int get_lca(int a, int b) {
    if (depth[a] < depth[b]) swap(a, b);
    int d = depth[a] - depth[b];
    int v = get(a, d);
    if (v == b) {
      return v;
    } else {
      for (int i = lg - 1; i >= 0; i--) {
        if (lift[v][i] != lift[b][i]) {
          v = lift[v][i];
          b = lift[b][i];
        }
      }
      return lift[b][0];
    }
  }
};

lca_lift lc;

int dfs(int a) {
  if (vi[a]) return 0; /* means parent */
  pre[a] = v[a];
  vi[a] = 1;
  for (int i: lc.edges[a]) pre[a] += dfs(i);
  return pre[a];
}

int main() {
  fin >> n >> k;
  lc.init(n);
  memset(v, 0, sizeof(v));
  memset(vi, 0, sizeof(vi));
  for (int i = 0; i < n - 1; i++) {
    int a, b;
    fin >> a >> b;
    lc.edge(--a, --b);
  }

  lc.init_lift();

  for (int i = 0; i < k; i++) {
    int a, b;
    fin >> a >> b;
    int q = lc.get_lca(--a, --b);
    v[a]++;
    v[b]++;
    v[q]--;
    if (q != 0) v[lc.lift[q][0]]--;
  }

  dfs(0);

  int m = -1;
  for (int i = 0; i < n; i++) m = max(m, pre[i]);
  fout << m << endl;
}