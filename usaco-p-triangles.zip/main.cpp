#include <bits/stdc++.h>
#include <chrono> 
 
using namespace std;
using namespace std::chrono; 
 
// #pragma GCC target ("avx2")
// #pragma GCC optimization ("O3")
// #pragma GCC optimization ("unroll-loops")
// #pragma optimization_level 3
// #pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math,O3")
// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define pb push_back
#define io {ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define mp make_pair
#define f first
#define s second
#define presum(p, a, n) {p[0] = a[0]; for (int i = 1; i < n; i++) p[i] = a[i] + p[i-1];}
#define all(v) v.begin(), v.end()
#define getunique(v) {sort(all(v)); v.erase(unique(all(v)), v.end());}
#define readgraph(list, edges) for (int i = 0; i < edges; i++) {int a, b; cin >> a >> b; a--; b--; list[a].pb(b); list[b].pb(a);}
#define ai(a, n) for (int ele = 0; ele < n; ele++) cin >> a[ele];
#define ain(a, lb, rb) for (int ele = lb; ele <= rb; ele++) cin >> a[ele];
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
#define aout(a, lb, rb) {for (int ele = lb; ele <= rb; ele++) { if (ele > lb) cout << " "; cout << a[ele]; } cout << '\n';}
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v);
template<typename A, typename B> ostream& operator<<(ostream &cout, pair<A, B> const &p) { return cout << "(" << p.f << ", " << p.s << ")"; }
template<typename A> ostream& operator<<(ostream &cout, vector<A> const &v) {
  cout << "["; for(int i = 0; i < v.size(); i++) {if (i) cout << ", "; cout << v[i];} return cout << "]";
}
 
// template<typename A, typename B> ll max(A x, B y) {
//   return x > y ? x : y;
// }
// template<typename A, typename B> ll min(A x, B y) {
//   return x < y ? x : y;
// }
 
mt19937 rng(steady_clock::now().time_since_epoch().count());
/* usage - just do rng() */
 
void usaco(string filename) {
  #pragma message("be careful, freopen may be wrong")
	freopen((filename + ".in").c_str(), "r", stdin);
	freopen((filename + ".out").c_str(), "w", stdout);
}
 
const ll mod = 1000000007;

ll n, m, k, q, Q, T, l, r, x, y, z;
ll a[1000005];
ll b[1000005];
ll c[1000005];
string s, t;
ll ans = 0;

using pt = pair<lld, lld>;
pt points[305];
int segs[305][305];
int cnt[305];

int main() {
  io;
  // freopen("case", "r", stdin);
  // freopen("test.txt", "r", stdin);
  // freopen("case", "w", stdout);
  // freopen("file.in", "r", stdin);
 
  usaco("triangles");

  cin >> n;
  f0r(i, n) cin >> points[i].f >> points[i].s;

  ms(cnt, 0);

  f0r(i, n) {
    f0r(j, n) {
      pt a = points[i], b = points[j];
      if (a.f > b.f) swap(a, b);
      
      f0r(k, n) {
        if (k == i || k == j) continue;
        
        pt c = points[k];
        if (a.f < c.f && c.f < b.f) {
          lld ypos = a.s + (b.s - a.s) * (c.f - a.f) / (b.f - a.f);
          if (c.s < ypos) ++segs[i][j];
        }
      }
    }
  }

  f0r(i, n) {
    f1r(j, i + 1, n) {
      f1r(k, j + 1, n) {
        ll id[3] = {i, j, k};

        int r = 0;
        f0r(l, 3) {
          int i1 = id[l], i2 = id[(l + 1) % 3];

          /* lower or upper line */
          if (points[i1].f < points[i2].f) r += segs[i1][i2];
          else r -= segs[i1][i2];
        }

        if (r < 0) r = -r;

        f0r(l, 3) {
          int i1 = id[l], i2 = id[(l + 1) % 3], i3 = id[(l + 2) % 3];
          pt a = points[i1], b = points[i2], c = points[i3];
          if (a.f > b.f) swap(a, b);

          if (a.f < c.f && c.f < b.f) {
            lld ypos = a.s + (b.s - a.s) * (c.f - a.f) / (b.f - a.f);
            if (c.s < ypos) --r;
          }
        }

        ++cnt[r];
      }
    }
  }

  f0r(i, n - 2) cout << cnt[i] << endl;
} 