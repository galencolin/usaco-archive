#include <bits/stdc++.h>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("snakes.in");
ofstream fout("snakes.out");
const int mn = 405;
const int mk = 404;
int n, dp[mn][mk]; //best at n, with k moves left
int arr[mn];
int pre[mn]; //cost from i to j
int maxa[mn][mn];

int cost(int i, int j) { // j >= i
  int q = i ? pre[i - 1] : 0;
  return maxa[i][j] * (j - i + 1) - (pre[j] - q);
}

void div(int k, int il, int ih, int optl, int optr) {
  if (il > ih) return;
  int mid = (il + ih) / 2;
  dp[mid][k] = 1e9;
  int opt = optl;
  for (int i = max(0, optl - 1); i <= min(mid, optr + 1); i++) {
    int v = cost(i, mid);
    if (i > 0) v += dp[i - 1][k - 1];
    if (v < dp[mid][k]) {
      dp[mid][k] = v;
      opt = i;
    }
  }

  div(k, il, mid - 1, optl, opt);
  div(k, mid + 1, ih, opt, optr);
}

void ptable() {
  for (int i = 0; i <= k; i++) {
    for (int j = 0; j < n; j++) {
      cout << dp[j][i] << " ";
    }
    cout << endl;
  }
}

int main() {
  fin >> n >> k;

  f0r(i, n) {
    fin >> arr[i];
    if (!i) pre[i] = arr[i];
    else pre[i] = pre[i-1] + arr[i];
    maxa[i][i] = arr[i];
  }

  for (int i = 0; i < n; i++) { //start
    for (int j = i+1; j < n; j++) { //end
      maxa[i][j] = max(arr[j], maxa[i][j-1]);
    }
  }

  f0r(i, n) dp[i][0] = cost(0, i);

  f1r(j, 1, k + 1) {
    div(j, 0, n-1, 0, n-1);
  }

  fout << dp[n - 1][k] << endl;
  // ptable();
}