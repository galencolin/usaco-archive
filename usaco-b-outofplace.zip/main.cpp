#include <bits/stdc++.h>
using namespace std;
ifstream fin("outofplace.in");
ofstream fout("outofplace.out");
typedef struct k k;
struct k {
  int v, i;
};
bool c(k a, k b) {
  if (a.v == b.v) return a.i < b.i;
  return a.v < b.v;
}
int main() {
  int n;
  fin >> n;
  k a[n];
  int j = 0, d;
  for (int i = 0; i < n; i++) {
    fin >> d;
    if (j && d == a[j-1].v) continue;
    a[j].v = d;
    a[j].i = j;
    j++;
  }
  sort(a, a+j, c);
  int m = 0;
  for (int i = 0; i < j; i++) {
    m = max(abs(a[i].i - i), m);
  }
  fout << m << endl;
}