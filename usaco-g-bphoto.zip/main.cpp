// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <algorithm>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("bphoto.in");
ofstream fout("bphoto.out");
const int mn = 100002;
struct cow {
  int ind, h;
};

bool cc(cow c1, cow c2) {
  if (c1.h == c2.h) return c1.ind < c2.ind;
  return c1.h < c2.h;
}

struct BIT {
  int arr[mn];

  BIT() {
    ms(arr, 0);
  }

  void add(int x, int v) {
    for(;x < mn; x += (x & -x)) {
      arr[x] += v;
    }
  }

  int query(int x) {
    int sum = 0;
    for(;x > 0; x -= (x & -x)) {
      sum += arr[x];
    }
    return sum;
  }
} tleft, tright;

int main() {
  int n;
  fin >> n;

  cow cows[n];
  cow oc[n];
  f0r(i, n) {
    fin >> cows[i].h;
    oc[i].h = cows[i].h;
    oc[i].ind = cows[i].ind = i;
  }

  //compress input
  sort(cows, cows+n, cc);
  int j = 0;
  f0r(i, n) {
    oc[cows[i].ind].h = j + 1;
    if (i < n - 1 && cows[i+1].h != cows[i].h) j++;
  }

  f1r(i, 1, n) tright.add(oc[i].h, 1);

  int unb = 0;
  f0r(i, n-1) {
    int lq = i - tleft.query(oc[i].h);
    int rq = (n - i - 1) - tright.query(oc[i].h);

    if ((lq > 0) ^ (rq > 0)) unb++;
    else if (lq && rq) {
      if ((float)max(lq, rq) / (float)min(lq, rq) > 2.00001) unb++;
    }
    tleft.add(oc[i].h, 1);
    tright.add(oc[i+1].h, -1);
  }
  if (tleft.query(oc[n-1].h)) unb++;
  fout << unb << endl;
}