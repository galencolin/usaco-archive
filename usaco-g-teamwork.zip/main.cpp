// #include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <set>

using namespace std;
#define f0r(a, b) for (a = 0; a < b; a++)
#define f1r(a, b, c) for (a = b; a < c; a++)
#define pb push_back
#define ms(arr, v) memset(arr, v, sizeof(arr))
typedef long long ll;
int i, j, k, q;
ifstream fin("teamwork.in");
ofstream fout("teamwork.out");

const short maxn = 10001, maxk = 1001;

int dp[maxn];

int main() {
  int n, k;
  fin >> n >> k;

  int skill[n];
  f0r(i, n) fin >> skill[i];

  dp[0] = skill[0];
  f1r(i, 1, n) {
    int ma = 0;
    dp[i] = 0;
    for (int j = i; j > max(0, i - k); j--) {
      ma = max(ma, skill[j]);
      dp[i] = max(dp[j-1] + (i-j+1)*ma, dp[i]);
    }
    if (i < k) dp[i] = max((i+1)*ma, dp[i]);
  }

  fout << dp[n-1] << endl;
}